package com.backoffice.Tests;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.testng.Assert;
import org.testng.Reporter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.backoffice.PageFactory.HomePage;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
public class TestCase_FSA_FDRapidConnect extends TestBaseClass {
	
	
	
	@Test(dataProvider="FDRapidConnectProcessorFSA")
	public void TestCase_FSA_FDRapid(String MerchantID,String MerchantCategoryCode, String RapidMerchantId,String terminallabel, String terminallabel1){
		
		  WebDriverWait w=new WebDriverWait(driver,20);
		 objHomePage = new HomePage(driver);
			
	     objHomePage.SetupStore(); 
	     objHomePage.SetupFindStore();
	     objHomePage.SetupFindStoreBYID(configFileReader.getStoreID());
	     objHomePage.SetupSubmitFindStore();
	     objHomePage.SetupViewModifyFindStore();
	     
	     
	     
	     
	     objHomePage.SetupFSAInfoLink();
	     objHomePage.SetupFSAProcessorname();
	     
		
	     
			
			
		   	//w.until(ExpectedConditions.elementToBeClickable(By.id("ca_mrcId")));
		    w.until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(By.id("ca_mrcId"))));
		     objHomePage.SetupFSAMerchantID(MerchantID);
		     w.until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(By.id("ca_mrcCategoryCode"))));
		     objHomePage.SetupPrepaidMerchantCode(MerchantCategoryCode);
		     objHomePage.SetupRapidConnectMerchantId(RapidMerchantId);
		     objHomePage.SetupTerminalLabelmain(terminallabel);
	    	 objHomePage.SetupTerminalIDmain(terminallabel1);
		     objHomePage.SetupGroupID();
		     objHomePage.SetupTPPID();
		     
		     
	    	// objHomePage.SetupTerminalID(terminallabel1);
		     objHomePage.clickFSASubmitInfo();
	    	 String ActualTitle = driver.findElement(By.className("message_content") ).getText();
	    	 String ExpectedTitle ="FSA Processor information added successfully.";
	    	 AssertJUnit.assertEquals(ExpectedTitle, ActualTitle);
	    	
	    	 
	    	 
	    	
	    	  
	
	}
	
	

	
	@DataProvider(name="FDRapidConnectProcessorFSA")
	public Object[][] loginData() {
		Object[][] arrayObject = getExcelData(sheetPath,"FDRapidConnectProcessor");
		return arrayObject;
	}

/*	@DataProvider(name="BlackHawkProcessorGift")
	public Object[][] loginData1() {
		Object[][] arrayObject = getExcelData(sheetPath,"BlackHawkProcessor");
		return arrayObject;
	}*/

	
	public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) {

				for (int j=0; j < totalNoOfCols; j++) {
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}

	
}
