package com.backoffice.Tests;
import org.testng.annotations.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;



//import PageFactory.Guru99Login;

public class Punch_Test2{
	static String methodName ="";
	 static void reverse(Integer myArray[]) 
	    { 
	        Collections.reverse(Arrays.asList(myArray)); 
	        System.out.println("Reversed Array:" + Arrays.asList(myArray)); 
	    } 
	 
	
	@Test (enabled=false)
	 public void reverse(){
		
		 Integer[] intArray = {10,20,30,40,50,60,70,80,90};
	     
		  //print array starting from first element
		    System.out.println("Original Array:");
		    for(int i=0;i<intArray.length;i++)
		         System.out.print(intArray[i] + "  ");
		     
		    System.out.println();
		     
		    //print array starting from last element
		    System.out.println("Original Array printed in reverse order:");
		         for(int i=intArray.length-1;i>=0;i--)
		         System.out.print(intArray[i] + "  ");
		        
		         
		         
		         Integer [] myArray = {1,3,5,7,9}; 
		         Integer [] myArray1 = {2,4,6,8,10}; 
		         System.out.println("Original Array:" + Arrays.asList(myArray));
		         System.out.println("Original Array:" + Arrays.asList(myArray1));
		         reverse(myArray); 
		         reverse(myArray1);
		    
	
	}

	    @Test (enabled=false)

	    public void readAllDetails(){
	    	String request = "getAutoInstallationDetails";
	    	
	    	// request the server
			//Response response = RestAssured.get("https://chercher.tech/sample/api/product/read");
			
			
			Response response = RestAssured.get("https://bookstore.toolsqa.com");
			//Response response = RestAssured.get("http://demo.guru99.com/V4/sinkministatement.php?CUSTOMER_ID=68195&PASSWORD=1234!&Account_No=1");
			
			//Response response = RestAssured.get("https://sgbo01.auruspay.com/whizpay/whizpayrestwebservice/formfactorInstallation_v2/getAutoInstallationDetails");
			//Response response = RestAssured.get("https://sgbo01.auruspay.com/auruspay/api/formfactorInstallation_v2/");
			
			//Response response = RestAssured.get("https://sgbo01.auruspay.com/whizpay/whizpayrestwebservice/formfactorInstallation_v2/");
			// store the response body in string
			
			//request = bulidFormFactorRequest(methodName);
			
			
			String responseBody = response.getBody().asString();
			// print the response
			System.out.println("Response Body is =>  " + responseBody);
			Reporter.log(responseBody);
			// store the response code
			int responseStatusCode = response.getStatusCode();
			System.out.println("************************************************");
			System.out.println("Status Code => "+ responseStatusCode);
			System.out.println(response.getTimeIn(TimeUnit.MILLISECONDS));
	    	
	    
	    
	    }
	    
	    
	    
	    @Test(enabled=false)
	    public void putDetails()
	    {
	    	RequestSpecification reqSpec = RestAssured.given();

	    	JSONObject jo = new JSONObject();
	    	jo.put("name", "myname");
	    	jo.put("description", "that is my name");
	    	jo.put("price", "122222");
	    	reqSpec.body(jo.toString());

	    	Response resp = reqSpec.put("https://chercher.tech/sample/api/product/create");
	    	System.out.println("Response code => " +resp.statusCode());
	    }
	    
	    
	    @Test(enabled=false)
	    public void postDetails()
	    {
	    	// request the server
	    	RequestSpecification reqSpec = RestAssured.given();

	    	JSONObject jo = new JSONObject();
	    	jo.put("id", "4000");
	    	jo.put("name", "vikram");
	    	jo.put("description", "Yes, I have updated the details");
	    	jo.put("price", "0.0");
	    	reqSpec.body(jo.toString());

	    	Response resp = reqSpec.post("https://chercher.tech/sample/api/product/update");
	    	
	    
	    }
	    
	    
	    @Test(enabled=false)
	    public void postREstDetails()
	    {
	    	// request the server
	    	RequestSpecification reqSpec = RestAssured.given();

	    	JSONObject jo = new JSONObject();
	    	jo.put("id", "4000");
	    	jo.put("name", "vikram");
	    	jo.put("description", "Yes, I have updated the details");
	    	jo.put("price", "0.0");
	    	reqSpec.body(jo.toString());

	    	Response resp = reqSpec.post("https://chercher.tech/sample/api/product/update");
	    }
	    
	    
	    @Test(enabled=false)
	    public void deleteDetails()
	    {
	    	// request the server
	    	RequestSpecification reqSpec = RestAssured.given();

	    	JSONObject jo = new JSONObject();
	    	jo.put("id", "94");

	    	reqSpec.body(jo.toString());

	    	Response resp = reqSpec.delete("https://chercher.tech/sample/api/product/delete");
	    }
	    /*
	    @Test

	    public void test_Add_Credit(){
	    	
	    	//WebDriverWait wait = new WebDriverWait(driver, 10);
	    	
	    	 objHomePage = new HomePage(driver);
			 objHomePage.SetupStore(); 
		     objHomePage.SetupFindStore();
		     objHomePage.SetupFindStoreBYID("12191418");
		     
	    	
	    
	    }*/
	    
	    
	    
	    
	/*  
	 @Test(dataProvider = "getLoginData")
	 public void LoginData()
	 {
 	objHomePage = new HomePage(driver);
  
 	objHomePage.SetupStore();   
 	objHomePage.setCorporate(configFileReader.getCorpName());
 	objHomePage.SetSubmitCorpSearch();
 	objHomePage.AddStoreLink();
 	objHomePage.setStoreName("vvv");
 	objHomePage.setStoreID("12191415");
 	objHomePage.SetupContrydrop();
 	objHomePage.SetupStatedrop();
 	objHomePage.setAddress1("sdfg");
 	objHomePage.setupCity("Pune");
 	objHomePage.setupZip("11111");
 	objHomePage.setupPhone("8275486383");
 	objHomePage.setupContactPerson("Vikram");
 	objHomePage.setupEmailID("vdhole@aurusinc.com");
 	objHomePage.SetupStoreTypedrop();
 	objHomePage.SetupLowerAmount("0");
 	objHomePage.SetupUpperAmount("100000");
 	
 	
 	
 	objHomePage.SubmitStorePage();
 	objHomePage.explicitWait();
 		    }
	*/
	
	
	
	
	
	/*
	
	    @Test(dataProvider = "getLoginData")
	    public void LoginData(String distID, String asmtId, String studID)
	            throws InterruptedException, BiffException, IOException {
	        Administartion(distID, asmtId, studID);
	    }

	    public void Administartion(String distID, String asmtId, String studID)
	            throws BiffException, IOException {
	        Workbook workbk = Workbook.getWorkbook(new File(sheetPath));
	        Sheet sht = workbk.getSheet("Sheet1");
	        int currRow = sht.findCell(studID).getRow();
	        System.out.println(sht.getCell(3, currRow).getContents() + "Gold Template Values");
	        System.out.println(sht.getCell(4, currRow).getContents() + "Used/Unused");
	    }*/
	    
	


    
	    
	    
	    

	    
	    
	   /////////////////////////////////To Read From Excel//////////////////////
	 /*  @Test
	    public void test_ReadExcel_Correct() throws BiffException, IOException
	    {
	    objutility = new Utility(driver);
	    objutility.readExcel();
	    }*/
	/////////////////////////////////////////////////////////////////////////////////
	
	
	
	

	
}
