package com.backoffice.Tests;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.backoffice.PageFactory.HomePage;

//import PageFactory.Guru99Login;

public class AddCredit extends TestBaseClass{
	

	
	
	
	
	   @Test(enabled=false)

	    public void TestCase_Add_Credit_Correct(){
	    	
	    	//WebDriverWait wait = new WebDriverWait(driver, 10);
		   WebDriverWait w=new WebDriverWait(driver, 5, 200);
		     objHomePage = new HomePage(driver);
			 objHomePage.SetupStore(); 
		     objHomePage.SetupFindStore();
		     objHomePage.SetupFindStoreBYID(configFileReader.getStoreID());
		     objHomePage.SetupSubmitFindStore();
		     objHomePage.SetupViewModifyFindStore();
		     
		     objHomePage.SetupCreditInfoLink();
		     objHomePage.SetupCreditProcessorname();
		     w.until(ExpectedConditions.elementToBeClickable(By.id("ca_mrcId")));
		     objHomePage.SetupCardAcceptorIDMain("542930525797973");
		     objHomePage.SetupTerminalLabelmain("111");
	    	 objHomePage.SetupTerminalIDmain("11111111");
	    	 objHomePage.SetupCreditSubmit();
	    	 String ActualTitle = driver.findElement(By.className("message_content") ).getText();
	    	 String ExpectedTitle ="Credit Processor information added successfully.";
	    	 AssertJUnit.assertEquals(ExpectedTitle, ActualTitle);
	    
	    
	    }
	
	
	   @Test(enabled=false)

	    public void TestCase_Add_Debit_Correct(){
	    	
	    	//WebDriverWait wait = new WebDriverWait(driver, 10);
		   WebDriverWait w1=new WebDriverWait(driver, 10);
		     objHomePage = new HomePage(driver);
			
		     
		     objHomePage.SetupDebitInfoLink();
		     objHomePage.SetupDebitProcessorname();
		     w1.until(ExpectedConditions.elementToBeClickable(By.id("ca_mrcId")));
		     objHomePage.SetupDebitCardAcceptorID("542930525797973");
		     objHomePage.SetupDebitTerminalLabel("111");
	    	 objHomePage.SetupDebitTerminalID("11111111");
	    	 objHomePage.SetupDebitSubmit();
	    	 String ActualTitle = driver.findElement(By.className("message_content") ).getText();
	    	 String ExpectedTitle ="Debit Processor information added successfully.";
	    	 AssertJUnit.assertEquals(ExpectedTitle, ActualTitle);
	    	
	    
	    }
	
	   @Test

	    public void TestCase_Add_PREPAID_Correct(){
	    	
	    	//WebDriverWait wait = new WebDriverWait(driver, 10);
		     WebDriverWait w2=new WebDriverWait(driver, 20);
		     objHomePage = new HomePage(driver);
		     objHomePage.SetupStore(); 
		     objHomePage.SetupFindStore();
		     objHomePage.SetupFindStoreBYID(configFileReader.getStoreID());
		     objHomePage.SetupSubmitFindStore();
		     objHomePage.SetupViewModifyFindStore();
		     
		     objHomePage.SetupPrepaidInfoLink();
		     //objHomePage.SetupCreditInfoLink();
		     
		     objHomePage.SetupPrepaidProcessorname();
		     w2.until(ExpectedConditions.elementToBeClickable(By.id("ca_mrcCategoryCode")));
		     
		     
		     
		     ////Merchant Category Code validation
		     
		     
		     objHomePage.SetupPrepaidMerchantCode("");
		     objHomePage.SetupPrepaidMerchantID("1234567855555555");
		     objHomePage.SetupPrepaidSubmit();
		     w2.until(ExpectedConditions.visibilityOfElementLocated(By.className("login")));
		     objHomePage.SetupErrorOk();
		     String alertMessage= driver.findElement(By.id("errorMsg")).getText();	
		     String ExpectedalertMessage="Please enter Merchant Category Code.";
		     AssertJUnit.assertEquals(ExpectedalertMessage, alertMessage);
		     Reporter.log(alertMessage+"Validation Checked");
		     
		     
		     objHomePage.SetupPrepaidMerchantCode("@#@#");
		     objHomePage.SetupPrepaidMerchantID("1234567855555555");
		     objHomePage.SetupPrepaidSubmit();
		     w2.until(ExpectedConditions.visibilityOfElementLocated(By.className("login")));
		     objHomePage.SetupErrorOk();
		     String alertMessage1= driver.findElement(By.id("errorMsg")).getText();	
		     String ExpectedalertMessage1="Merchant Category Code must be numeric.";
		     AssertJUnit.assertEquals(ExpectedalertMessage1, alertMessage1);
		     Reporter.log(alertMessage1+"Validation Checked");
		     
		     
		     objHomePage.SetupPrepaidMerchantCode("4444");
		     objHomePage.SetupPrepaidMerchantID("@!$!$!");
		     objHomePage.SetupPrepaidSubmit();
		     w2.until(ExpectedConditions.visibilityOfElementLocated(By.className("login")));
		     objHomePage.SetupErrorOk();
		     String alertMessage2= driver.findElement(By.id("errorMsg")).getText();	
		     String ExpectedalertMessage2="Marchant ID must not contain special characters.";
		     AssertJUnit.assertEquals(ExpectedalertMessage2, alertMessage2);
		     Reporter.log(alertMessage2+"Validation Checked");
		     
		   
		     
		    
		  
		     objHomePage.SetupPrepaidMerchantCode("6666");
		     objHomePage.SetupPrepaidMerchantID("1234567891122222222");
		     //objHomePage.SetupAddAnotherProcessor();
		     objHomePage.SetupPrepaidSubmit();
	    	 String ActualTitle = driver.findElement(By.className("message_content") ).getText();
	    	 String ExpectedTitle ="PREPAID Processor information added successfully.";
	    	 AssertJUnit.assertEquals(ExpectedTitle, ActualTitle);
	    	 Reporter.log(ExpectedTitle+"in StoreID: "+configFileReader.getStoreID());
	    	 
	    	 
	    	 
	    	 ///PrimarySecondary Check
	    	 //w2.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("message_content")));
	    	 
	    	 if(driver.findElement(By.id("ar_tenderType")).isSelected())
	    	 {
	    	 objHomePage.SetupAddAnotherProcessor();
	    	 objHomePage.SetupSecondaryPrepaidProcessorname();
		     w2.until(ExpectedConditions.elementToBeClickable(By.id("ar_mrcCategoryCode")));
	    	 objHomePage.SetupSecondaryPrepaidMerchantCode("5555");
		     objHomePage.SetupSecondaryPrepaidMerchantID("1234567891122222222");
	    	 objHomePage.SetupPrepaidSubmit();
	    	 String SecActualTitle = driver.findElement(By.className("message_content") ).getText();
	    	 String SecExpectedTitle ="PREPAID Processor information added successfully.";
	    	 AssertJUnit.assertEquals(SecExpectedTitle, SecActualTitle);
	    	 Reporter.log("Primary Secondary checked "+"in StoreID: "+configFileReader.getStoreID());
	    	 }
	    	 
	    	 
	    	 //Onboarding Check
	    	 objHomePage.SetupHelpDeskMangement();
	    	 objHomePage.SetupBulkStore();
	    	 objHomePage.setCorporate(configFileReader.getCorpName());
		     objHomePage.SetupCreditSubmit();
		     objHomePage.SetupOperation();
		     objHomePage.SetupFileUpload();
		     objHomePage.SetupUploadButtonFile();
		     objHomePage.SetupShedularButton();
		     Reporter.log("Onboarding Done Successfully");
	    
	    }
	   
	 
	
}
