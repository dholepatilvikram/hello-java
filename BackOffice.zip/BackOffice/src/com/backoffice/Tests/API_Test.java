package com.backoffice.Tests;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
//import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;



//import PageFactory.Guru99Login;

public class API_Test{
	static String methodName ="";
	 static void reverse(Integer myArray[]) 
	    { 
	        Collections.reverse(Arrays.asList(myArray)); 
	        System.out.println("Reversed Array:" + Arrays.asList(myArray)); 
	    } 
	 
	
	@Test
	 public void reverse(){
		
		 Integer[] intArray = {10,20,30,40,50,60,70,80,90};
	     
		  //print array starting from first element
		    System.out.println("Original Array:");
		    for(int i=0;i<intArray.length;i++)
		         System.out.print(intArray[i] + "  ");
		     
		    System.out.println();
		     
		    //print array starting from last element
		    System.out.println("Original Array printed in reverse order:");
		         for(int i=intArray.length-1;i>=0;i--)
		         System.out.print(intArray[i] + "  ");
		        
		         
		         
		         Integer [] myArray = {1,3,5,7,9}; 
		         Integer [] myArray1 = {2,4,6,8,10}; 
		         System.out.println("Original Array:" + Arrays.asList(myArray));
		         System.out.println("Original Array:" + Arrays.asList(myArray1));
		         reverse(myArray); 
		         reverse(myArray1);
		    
	
		         
		         
		         
		         
	}

	/*    @Test  (enabled=false)

	    public void readAPIDetails(){
	    	
	    	
	    	// request the server
			//Response response = RestAssured.get("https://chercher.tech/sample/api/product/read");
			
	    	   String userID = "9b5f49ab-eea9-45f4-9d66-bcf56a531b85";
	           String userName = "TOOLSQA-Test";
	           String password = "Test@@123";
	           String baseUrl = "https://bookstore.toolsqa.com";

	           RestAssured.baseURI = baseUrl;
	           RequestSpecification request = RestAssured.given();


	           //Step - 1
	           //Test will start from generating Token for Authorization
	           request.header("Content-Type", "application/json");

	           Response response = request.body("{ \"userName\":\"" + userName + "\", \"password\":\"" + password + "\"}")
	                   .post("/Account/v1/GenerateToken");

	           Assert.assertEquals(response.getStatusCode(), 200);
		 
			  response = RestAssured.get("/BookStore/v1/Books");

			  int responseStatusCode = response.getStatusCode();
			  
		        Assert.assertEquals(response.getStatusCode(), 200);
		        System.out.println("Status Code => "+ responseStatusCode);
		        String jsonString = response.asString();
		        jsonString = response.asString();
		        List<Map<String, String>> books = JsonPath.from(jsonString).get("books");
		        Assert.assertTrue(books.size() > 0);
		        
		        
		        
		        String token = JsonPath.from(jsonString).get("token");

			
		        //Step - 5
		        // Get User
		        request.header("Authorization", "Bearer " + token)
		                .header("Content-Type", "application/json");

		        response = request.get("/Account/v1/User/" + userID);
		        Assert.assertEquals(200, response.getStatusCode());

		        jsonString = response.asString();
		        List<Map<String, String>> booksOfUser = JsonPath.from(jsonString).get("books");
		        Assert.assertEquals(0, booksOfUser.size());
			
			
			
	    
	    }
	  */  
	    public void readAllDetails(){
	    	String request = "getAutoInstallationDetails";
	    	
	    	// request the server
			//Response response = RestAssured.get("https://chercher.tech/sample/api/product/read");
			
			
			Response response = RestAssured.get("https://bookstore.toolsqa.com");
				
			
			String responseBody = response.getBody().asString();
			// print the response
			System.out.println("Response Body is =>  " + responseBody);
			Reporter.log(responseBody);
			// store the response code
			int responseStatusCode = response.getStatusCode();
			System.out.println("************************************************");
			System.out.println("Status Code => "+ responseStatusCode);
			System.out.println(response.getTimeIn(TimeUnit.MILLISECONDS));
	    	
	    
			    response = RestAssured.get("/BookStore/v1/Books");

		        AssertJUnit.assertEquals(response.getStatusCode(), 200);
		        String jsonString = response.asString();
		        jsonString = response.asString();
		//        List<Map<String, String>> books = JsonPath.from(jsonString).get("books");
		  //      Assert.assertTrue(books.size() > 0);

			
			
			
			
			
	    
	    }
	    @Test(enabled=false)
	    public void RegistrationSuccessful() {
	        RestAssured.baseURI = "https://bookstore.toolsqa.com";
	        RequestSpecification request = RestAssured.given();

	        JSONObject requestParams = new JSONObject();
	        /*I have put a unique username and password as below,
	        you can enter any as per your liking. */
	        requestParams.put("UserName", "TOOLSQA-Test");
	        requestParams.put("Password", "Test@@123");

	        request.body(requestParams.toJSONString());
	        Response response = request.post("/Account/v1/User");

	        AssertJUnit.assertEquals(response.getStatusCode(), 201);
	        // We will need the userID in the response body for our tests, please save it in a local variable
	        //String userID = response.getBody().jsonPath().getString("userID");
	    }

	    
	    @Test(enabled=false)
	    public void putDetails()
	    {
	    	RequestSpecification reqSpec = RestAssured.given();

	    	JSONObject jo = new JSONObject();
	    	jo.put("name", "myname");
	    	jo.put("description", "that is my name");
	    	jo.put("price", "122222");
	    	reqSpec.body(jo.toString());

	    	Response resp = reqSpec.put("https://chercher.tech/sample/api/product/create");
	    	System.out.println("Response code => " +resp.statusCode());
	    }
	    
	    
	    @Test(enabled=false)
	    public void postDetails()
	    {
	    	// request the server
	    	RequestSpecification reqSpec = RestAssured.given();

	    	JSONObject jo = new JSONObject();
	    	jo.put("id", "4000");
	    	jo.put("name", "vikram");
	    	jo.put("description", "Yes, I have updated the details");
	    	jo.put("price", "0.0");
	    	reqSpec.body(jo.toString());

	    	Response resp = reqSpec.post("https://chercher.tech/sample/api/product/update");
	    	
	    
	    }
	    
	    
	    @Test(enabled=false)
	    public void postREstDetails()
	    {
	    	// request the server
	    	RequestSpecification reqSpec = RestAssured.given();

	    	JSONObject jo = new JSONObject();
	    	jo.put("id", "4000");
	    	jo.put("name", "vikram");
	    	jo.put("description", "Yes, I have updated the details");
	    	jo.put("price", "0.0");
	    	reqSpec.body(jo.toString());

	    	Response resp = reqSpec.post("https://chercher.tech/sample/api/product/update");
	    }
	    
	    
	    @Test(enabled=false)
	    public void deleteDetails()
	    {
	    	// request the server
	    	RequestSpecification reqSpec = RestAssured.given();

	    	JSONObject jo = new JSONObject();
	    	jo.put("id", "94");

	    	reqSpec.body(jo.toString());

	    	Response resp = reqSpec.delete("https://chercher.tech/sample/api/product/delete");
	    }
	    /*
	    @Test

	    public void test_Add_Credit(){
	    	
	    	//WebDriverWait wait = new WebDriverWait(driver, 10);
	    	
	    	 objHomePage = new HomePage(driver);
			 objHomePage.SetupStore(); 
		     objHomePage.SetupFindStore();
		     objHomePage.SetupFindStoreBYID("12191418");
		     
	    	
	    
	    }*/
	    
	    
	    
	    
	/*  
	 @Test(dataProvider = "getLoginData")
	 public void LoginData()
	 {
 	objHomePage = new HomePage(driver);
  
 	objHomePage.SetupStore();   
 	objHomePage.setCorporate(configFileReader.getCorpName());
 	objHomePage.SetSubmitCorpSearch();
 	objHomePage.AddStoreLink();
 	objHomePage.setStoreName("vvv");
 	objHomePage.setStoreID("12191415");
 	objHomePage.SetupContrydrop();
 	objHomePage.SetupStatedrop();
 	objHomePage.setAddress1("sdfg");
 	objHomePage.setupCity("Pune");
 	objHomePage.setupZip("11111");
 	objHomePage.setupPhone("8275486383");
 	objHomePage.setupContactPerson("Vikram");
 	objHomePage.setupEmailID("vdhole@aurusinc.com");
 	objHomePage.SetupStoreTypedrop();
 	objHomePage.SetupLowerAmount("0");
 	objHomePage.SetupUpperAmount("100000");
 	
 	
 	
 	objHomePage.SubmitStorePage();
 	objHomePage.explicitWait();
 		    }
	*/
	
	
	
	
	
	/*
	
	    @Test(dataProvider = "getLoginData")
	    public void LoginData(String distID, String asmtId, String studID)
	            throws InterruptedException, BiffException, IOException {
	        Administartion(distID, asmtId, studID);
	    }

	    public void Administartion(String distID, String asmtId, String studID)
	            throws BiffException, IOException {
	        Workbook workbk = Workbook.getWorkbook(new File(sheetPath));
	        Sheet sht = workbk.getSheet("Sheet1");
	        int currRow = sht.findCell(studID).getRow();
	        System.out.println(sht.getCell(3, currRow).getContents() + "Gold Template Values");
	        System.out.println(sht.getCell(4, currRow).getContents() + "Used/Unused");
	    }*/
	    
	


    
	    
	    
	    

	    
	    
	   /////////////////////////////////To Read From Excel//////////////////////
	 /*  @Test
	    public void test_ReadExcel_Correct() throws BiffException, IOException
	    {
	    objutility = new Utility(driver);
	    objutility.readExcel();
	    }*/
	/////////////////////////////////////////////////////////////////////////////////
	
	
	
	

	
}
