package com.backoffice.Tests;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import com.backoffice.PageFactory.LoginPage;

//import PageFactory.Guru99Login;

public class LoginWithPageFactory extends TestBaseClass{
	
	    

	    @Test(priority=0)

	    public void test_Home_Page_Appear_Correct(){
	    	
	  	    	

	    objLogin = new LoginPage(driver);

	    //Verify login page title

	    //String loginPageTitle = objLogin.getLoginTitle();

	   // Assert.assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));

	    //login to application

	    
	    
	    
	    
	    objLogin.loginToGuru99(configFileReader.getUserName(),configFileReader.getPassword());
	    
	    if(driver.getPageSource().contains("Favorite movie"))
    	{
	    	objLogin.setSecurityAnswer(configFileReader.getSecurityMovieAnswer());
    	}
	    else if(driver.getPageSource().contains("Favorite city"))
	    {
	    	objLogin.setSecurityAnswer(configFileReader.getSecurityCityAnswer());
	    }
	    else if(driver.getPageSource().contains("Favorite fruit"))
	    {
	    	objLogin.setSecurityAnswer(configFileReader.getSecurityFruitAnswer());
	    }
	    objLogin.clickSecurityPageSubmit();
	    
	    objLogin.setODT(configFileReader.getODT());
	    
	    objLogin.clickODTPageSubmit();
	    
	    // go the next page



	    //Verify home page

	   // Assert.assertTrue(objHomePage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mgr123"));

	    
	    }

}
