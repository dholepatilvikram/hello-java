package com.backoffice.Tests;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.backoffice.PageFactory.HomePage;


//import PageFactory.Guru99Login;

public class AddStore extends TestBaseClass{
	 

	    @Test	

	    public void test_Add_Store_Correct(){
	    	
	    	//WebDriverWait wait = new WebDriverWait(driver, 10);
	    	
	    	objHomePage = new HomePage(driver);
	     
	    	objHomePage.SetupStore();   
	    	objHomePage.setCorporate(configFileReader.getCorpName());
	    	objHomePage.SetSubmitCorpSearch();
	    	objHomePage.AddStoreLink();
	    	objHomePage.setStoreName("Ecom Test");
	    	objHomePage.setStoreID(configFileReader.getStoreID());
	    	objHomePage.SetupContrydrop();
	    	objHomePage.SetupStatedrop();
	    	objHomePage.setAddress1("sdfg");
	    	objHomePage.setupCity("Pune");
	    	objHomePage.setupZip("11111");
	    	objHomePage.setupPhone("8275486383");      
	    	objHomePage.setupContactPerson("Vikram");
	    	objHomePage.setupEmailID("vdhole@aurusinc.com");
	    	objHomePage.SetupStoreTypedrop();
	    	objHomePage.SetupLowerAmount("0");
	    	objHomePage.SetupUpperAmount("100000");
	    	
	    	
	    	
	    	objHomePage.SubmitStorePage();
	    	objHomePage.explicitWait();
	    	
	    	
	    
	    
	    }
	    
	   
	    /*
	    @Test

	    public void test_Add_Credit(){
	    	
	    	//WebDriverWait wait = new WebDriverWait(driver, 10);
	    	
	    	 objHomePage = new HomePage(driver);
			 objHomePage.SetupStore(); 
		     objHomePage.SetupFindStore();
		     objHomePage.SetupFindStoreBYID("12191418");
		     
	    	
	    
	    }*/
	    
	    
	    
	    
	/*  
	 @Test(dataProvider = "getLoginData")
	 public void LoginData()
	 {
 	objHomePage = new HomePage(driver);
  
 	objHomePage.SetupStore();   
 	objHomePage.setCorporate(configFileReader.getCorpName());
 	objHomePage.SetSubmitCorpSearch();
 	objHomePage.AddStoreLink();
 	objHomePage.setStoreName("vvv");
 	objHomePage.setStoreID("12191415");
 	objHomePage.SetupContrydrop();
 	objHomePage.SetupStatedrop();
 	objHomePage.setAddress1("sdfg");
 	objHomePage.setupCity("Pune");
 	objHomePage.setupZip("11111");
 	objHomePage.setupPhone("8275486383");
 	objHomePage.setupContactPerson("Vikram");
 	objHomePage.setupEmailID("vdhole@aurusinc.com");
 	objHomePage.SetupStoreTypedrop();
 	objHomePage.SetupLowerAmount("0");
 	objHomePage.SetupUpperAmount("100000");
 	
 	
 	
 	objHomePage.SubmitStorePage();
 	objHomePage.explicitWait();
 		    }
	*/
	
	
	
	
	
	/*
	
	    @Test(dataProvider = "getLoginData")
	    public void LoginData(String distID, String asmtId, String studID)
	            throws InterruptedException, BiffException, IOException {
	        Administartion(distID, asmtId, studID);
	    }

	    public void Administartion(String distID, String asmtId, String studID)
	            throws BiffException, IOException {
	        Workbook workbk = Workbook.getWorkbook(new File(sheetPath));
	        Sheet sht = workbk.getSheet("Sheet1");
	        int currRow = sht.findCell(studID).getRow();
	        System.out.println(sht.getCell(3, currRow).getContents() + "Gold Template Values");
	        System.out.println(sht.getCell(4, currRow).getContents() + "Used/Unused");
	    }*/
	    
	


    
	    
	    
	    

	    
	    
	   /////////////////////////////////To Read From Excel//////////////////////
	 /*  @Test
	    public void test_ReadExcel_Correct() throws BiffException, IOException
	    {
	    objutility = new Utility(driver);
	    objutility.readExcel();
	    }*/
	/////////////////////////////////////////////////////////////////////////////////
	
	
	
	

	
}
