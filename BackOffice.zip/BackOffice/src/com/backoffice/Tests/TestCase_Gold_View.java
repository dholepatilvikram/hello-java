package com.backoffice.Tests;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.backoffice.PageFactory.HomePage;
public class TestCase_Gold_View extends TestBaseClass {
	
	
	
	
	@Test
	public void TestCase_View_Gold(){
		
		  WebDriverWait w=new WebDriverWait(driver, 10);
		 objHomePage = new HomePage(driver);
	
		
		
	     objHomePage.SetupTemplateSystem();
	     objHomePage.SetupGoldTemplate();
	  
	     objHomePage.SetupModifyGoldTemplate();
	     objHomePage.SetupViewGoldTemplate();
	     w.until(ExpectedConditions.elementToBeClickable(By.id("corporateName")));
	     
	     
	    objHomePage.setCorporate(configFileReader.getCorpName()); 
	    objHomePage.SetupContrydropSearch();
	    objHomePage.SetupTerminalTYpedropSearch();
		w.until(ExpectedConditions.elementToBeClickable(By.id("modelName")));
	    objHomePage.SetupCreditSubmit();
	     
	    objHomePage.SetupSelectBaseApplication();
	    w.until(ExpectedConditions.elementToBeClickable(By.id("goldTemplateName")));
	    objHomePage.SetupSelectGoldTemplateName();
	    
	  
	  	
	 /*
	  	objHomePage.SetupGoldFileUpload();
		w.until(ExpectedConditions.elementToBeClickable(By.id("uploadGoldTemplate")));
	  	objHomePage.SetupGoldTemplateSubmit();
	
	  	
	  	List<WebElement> els = driver.findElements(By.xpath("//input[@type='checkbox']"));

		for ( WebElement el : els ) {
		    if ( !el.isSelected() ) {
		        el.click();
		    }
		}
	  
		
		objHomePage.SetupGoldTemplateEmailApproval("vdhole@aurusinc.com");
		objHomePage.SetupUploadButtonFile();
		
		
		
		 String ActualTitle = driver.findElement(By.className("message_content") ).getText();
    	 String ExpectedTitle ="Gold Template Modified successfully";
    	 Assert.assertEquals(ExpectedTitle, ActualTitle);*/
		
		
	
	}
	
	

}
