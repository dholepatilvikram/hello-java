package com.backoffice.Tests;
import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import com.backoffice.Config.ConfigFileReader;
import com.backoffice.Config.Utility;
import com.backoffice.PageFactory.HomePage;
import com.backoffice.PageFactory.LoginPage;
import com.backoffice.PageFactory.MainPage;
public class TestBaseClass {
	
	
	
	 String driverPath = "chromedriver";
	 private Properties properties;
	 private final String propertyFilePath= "Config//datafile.properties";
	  protected String sheetPath = "Config//Auto_Increment.xls";


	// File file = new File("~/home/vdhole/eclipse-workspace/BackOffice/Config/datafile.properties");
	    
	    WebDriver driver;

	    LoginPage objLogin;

	    HomePage objHomePage; 
	    
	    MainPage objMainpage;
	    
	    Utility objutility;
	    
	    protected ConfigFileReader configFileReader;

	    @BeforeTest

	    public void setup(){
	    	
			Reporter.log("=====Browser Session Started=====", true);
			
			configFileReader= new ConfigFileReader();
			

	       // System.setProperty("webdriver.firefox.marionette", driverPath);
	        
	       // driver = new FirefoxDriver();
	        
	        System.setProperty("webdriver.chrome.driver", driverPath);
	        driver = new ChromeDriver();
	        
	        driver.manage().window().maximize();
	        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	      // driver.get("http://demo.guru99.com/V4/");
	        
	       // driver.get(configFileReader.getApplicationUrl());
	        driver.get(configFileReader.getApplicationUrl2());
	        
	        
	        
	        
	       
	    }
	    
	   
	    
	    @BeforeClass

	    public void test_Home_Page_Appear_Correct(){
	    	
	  	    	

	    objLogin = new LoginPage(driver);

	    //Verify login page title

	    //String loginPageTitle = objLogin.getLoginTitle();

	   // Assert.assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));

	    //login to application

	    
	    
	  
	    
	    objLogin.loginToGuru99(configFileReader.getUserName(),configFileReader.getPassword());
	    
	    
	    
	    //UAT
	    
	    if(driver.getPageSource().contains("Favorite movie"))
    	{
	    	objLogin.setSecurityAnswer(configFileReader.getSecurityMovieAnswer());
    	}
	    else if(driver.getPageSource().contains("Favorite city"))
	    {
	    	objLogin.setSecurityAnswer(configFileReader.getSecurityCityAnswer());
	    }
	    else if(driver.getPageSource().contains("Favorite fruit"))
	    {
	    	objLogin.setSecurityAnswer(configFileReader.getSecurityFruitAnswer());
	    }
	    objLogin.clickSecurityPageSubmit();
	    
	    
	    
	    
	    
	    objLogin.setODT(configFileReader.getODT());
	    
	    objLogin.clickODTPageSubmit();
	   
	    // go the next page



	    //Verify home page

	   // Assert.assertTrue(objHomePage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mgr123"));

	    
	    }
	    
	    
	   
	    @AfterMethod //AfterMethod annotation - This method executes after every test execution
		public void screenShot(ITestResult result)throws IOException{
		//using ITestResult.FAILURE is equals to result.getStatus then it enter into if condition
			if(ITestResult.FAILURE==result.getStatus()){
				//try{
					// To create reference of TakesScreenshot
					TakesScreenshot screenshot=(TakesScreenshot)driver;
					// Call method to capture screenshot
					File src=screenshot.getScreenshotAs(OutputType.FILE);
					// Copy files to specific location 
					// result.getName() will return name of test case so that screenshot name will be same as test case name
					FileUtils.copyFile(src, new File("Screenshot//"+result.getName()+".png"));
					System.out.println("Successfully captured a screenshot");
				//}
				//catch (Exception e){
				//	System.out.println("Exception while taking screenshot "+e.getMessage());
				//} 
		}
		driver.quit();
		}
	   
	  
}
