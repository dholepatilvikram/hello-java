package com.backoffice.Tests;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.backoffice.PageFactory.HomePage;
public class TestCase_Gold_Modify extends TestBaseClass {
	
	
	
	
	@Test
	public void TestCase_Modify_Gold(){
		
		  WebDriverWait w=new WebDriverWait(driver, 10);
		 objHomePage = new HomePage(driver);
			
	    /* objHomePage.SetupStore(); 
	     objHomePage.SetupFindStore();
	     objHomePage.SetupFindStoreBYID(configFileReader.getStoreID());
	     objHomePage.SetupSubmitFindStore();
	     objHomePage.SetupViewModifyFindStore();*/
	     
	     
	     objHomePage.SetupTemplateSystem();
	     objHomePage.SetupTemplate();
	     objHomePage.SetupGoldTemplate();
	     
	     objHomePage.SetupModifyGoldTemplate();
	     
	     
	     objHomePage.setCorporate(configFileReader.getCorpName()); 
	     w.until(ExpectedConditions.elementToBeClickable(By.id("glTemplateName1")));
	     objHomePage.SetupGoldTemplateName1("Vikram_v30.7_MX915_272");
	  	 objHomePage.SetupContrydropSearch();
	  	 objHomePage.SetupTerminalTYpedropSearch();
	  	 objHomePage.SetupCreditSubmit();
	 
	  	
	  	
	  	//SetupGoldTemplateSubmit
	  	
	 
	  	objHomePage.SetupGoldFileUpload();
		w.until(ExpectedConditions.elementToBeClickable(By.id("uploadGoldTemplate")));
	  	objHomePage.SetupGoldTemplateSubmit();
	
	  	
	  	List<WebElement> els = driver.findElements(By.xpath("//input[@type='checkbox']"));

		for ( WebElement el : els ) {
		    if ( !el.isSelected() ) {
		        el.click();
		    }
		}
	  
		
		objHomePage.SetupGoldTemplateEmailApproval("vdhole@aurusinc.com");
		objHomePage.SetupUploadButtonFile();
		
		
		
		 String ActualTitle = driver.findElement(By.className("message_content") ).getText();
    	 String ExpectedTitle ="Gold Template Modified successfully";
    	 AssertJUnit.assertEquals(ExpectedTitle, ActualTitle);
		
			/*
		   	w.until(ExpectedConditions.elementToBeClickable(By.id("ca_mrcId")));
		     objHomePage.SetupCardAcceptorID(MerchantID);
		     objHomePage.SetupTerminalLabel(terminallabel);
	    	 objHomePage.SetupTerminalID(terminallabel1);
	    	 objHomePage.SetupCreditSubmit();
	    	 String ActualTitle = driver.findElement(By.className("message_content") ).getText();
	    	 String ExpectedTitle ="Credit Processor information added successfully.";
	    	 Assert.assertEquals(ExpectedTitle, ActualTitle);*/
	
	}
	
	

}
