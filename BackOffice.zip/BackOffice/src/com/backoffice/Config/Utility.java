package com.backoffice.Config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.backoffice.Tests.TestBaseClass;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Utility extends TestBaseClass{
	WebDriver driver;

	String[][] tabArray = null;
    Workbook workbk;
    Sheet sheet;
    int rowCount, colCount;
   // String sheetPath = "Config//Auto_Increment.xls";
    
    public Utility(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }   

    /*
	 // Excel API to read test data from excel workbook
    public String[][] getExcelData(String xlPath, String shtName)
            throws Exception {
        Workbook workbk = Workbook.getWorkbook(new File(xlPath));
        Sheet sht = workbk.getSheet(shtName);
        rowCount = sht.getRows();
        colCount = sht.getColumns();
        tabArray = new String[rowCount][colCount - 2];
        System.out.println("erow: " + rowCount);
        System.out.println("ecol: " + colCount);
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < 3; j++) {
                tabArray[i][j] = sht.getCell(j, i).getContents();
            }
        }
        return (tabArray);
    }
    
    @DataProvider
    public Object[][] getLoginData() throws Exception {
        Object[][] retObjArr = getExcelData(sheetPath, "Sheet1");
        System.out.println("getData function executed!!");
        return retObjArr;
    }*/
    
    
   /*
    @DataProvider(name="excelData")
    public Object[][] readExcel() throws InvalidFormatException, IOException {
        return ExcelRedaer.readExcel(filePath, sheetName);
    }*/
    /*
    ////////////////////////To Read from Excel
  public void readExcel() throws BiffException, IOException {
		String FilePath = "D:\\sampledoc.xls";
		FileInputStream fs = new FileInputStream(sheetPath);
		Workbook wb = Workbook.getWorkbook(fs);

		// TO get the access to the sheet
		Sheet sh = wb.getSheet("Sheet1");

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		for (int row = 0; row < totalNoOfRows; row++) {

			for (int col = 0; col < totalNoOfCols; col++) {
				System.out.print(sh.getCell(col, row).getContents() + "\t");
			}
			System.out.println();
		}
	}
*/
  ////////////////////////////////////////////////////////////  

   
    
    public String[][] getExcelData(String fileName, String sheetName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) {

				for (int j=0; j < totalNoOfCols; j++) {
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}

   
  

    
    
    
    
    
    
    
}
