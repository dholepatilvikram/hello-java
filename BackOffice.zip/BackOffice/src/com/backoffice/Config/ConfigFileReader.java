package com.backoffice.Config;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigFileReader {
	private Properties properties;
	private final String propertyFilePath= "Config//datafile.properties";


	
	public ConfigFileReader(){
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(propertyFilePath));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
		}		
	}
	
	public String getDriverPath(){
		String driverPath = properties.getProperty("driverPath");
		if(driverPath!= null) return driverPath;
		else throw new RuntimeException("driverPath not specified in the Configuration.properties file.");		
	}
	
	public long getImplicitlyWait() {		
		String implicitlyWait = properties.getProperty("implicitlyWait");
		if(implicitlyWait != null) return Long.parseLong(implicitlyWait);
		else throw new RuntimeException("implicitlyWait not specified in the Configuration.properties file.");		
	}
	
	public String getApplicationUrl() {
		String url = properties.getProperty("URL");
		if(url != null) return url;
		else throw new RuntimeException("url not specified in the Configuration.properties file.");
	}
	public String getApplicationUrl2() {
		String url = properties.getProperty("URL2");
		if(url != null) return url;
		else throw new RuntimeException("url not specified in the Configuration.properties file.");
	}
	
	public String getUserName() {
		String url = properties.getProperty("username");
		if(url != null) return url;
		else throw new RuntimeException("username not specified in the Configuration.properties file.");
	}
	
	
	public String getPassword() {
		String url = properties.getProperty("Password");
		if(url != null) return url;
		else throw new RuntimeException("Password not specified in the Configuration.properties file.");
	}
	
	public String getSecurityMovieAnswer() {
		String url = properties.getProperty("MovieSecurity");
		if(url != null) return url;
		else throw new RuntimeException("MovieSecurity not specified in the Configuration.properties file.");
	}
	
	public String getSecurityCityAnswer() {
		String url = properties.getProperty("Favoritecity");
		if(url != null) return url;
		else throw new RuntimeException("Favoritecity not specified in the Configuration.properties file.");
	}
	
	public String getSecurityFruitAnswer() {
		String url = properties.getProperty("Favoritefruit");
		if(url != null) return url;
		else throw new RuntimeException("Favoritefruit not specified in the Configuration.properties file.");
	}
	public String getODT() {
		String url = properties.getProperty("ODT");
		if(url != null) return url;
		else throw new RuntimeException("ODT not specified in the Configuration.properties file.");
	}
	public String getCorpName() {
		String url = properties.getProperty("CorpName");
		if(url != null) return url;
		else throw new RuntimeException("CorpName not specified in the Configuration.properties file.");
	}
	public String getStoreID() {
		String storeid = properties.getProperty("Storeid");
		if(storeid != null) return storeid;
		else throw new RuntimeException("Store Id not specified in the Configuration.properties file.");
	}
	
	public String getDepartmentType() {
		String departtype = properties.getProperty("DepartmentType");
		if(departtype != null) return departtype;
		else throw new RuntimeException("Department Type  not specified in the Configuration.properties file.");
	}
	
	
	
}
