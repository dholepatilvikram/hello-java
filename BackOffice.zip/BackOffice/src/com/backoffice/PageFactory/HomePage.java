package com.backoffice.PageFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.backoffice.Tests.TestBaseClass;

public class HomePage extends TestBaseClass {
	WebDriver driver;
	private final String onboardingFilePath= "/home/vdhole/eclipse-workspace/BackOffice/Config/blacky.csv";
	private final String goldFilePath= "/home/vdhole/eclipse-workspace/BackOffice/Config/GoldTemplateXLS_corp_6382_v11.06.xls";
	 
    
    @FindBy(linkText="Setup Store")

    WebElement setupStore;    
    
    @FindBy(id="corporateName")

    WebElement setupCorporateName;    
    
    @FindBy(id="SubmitCorporateSearch")

    WebElement submitcorpsearch;
    
    
    @FindBy(partialLinkText="Add Sto")

    WebElement AddStorelink;  
    
    
    @FindBy(id="storeNameDemographic")

    WebElement setupstoreNameDemographic;    
    
    @FindBy(id="storeIdDemographic")

    WebElement setupstoreIdDemographic;    
      
    
    @FindBy(id="submitButton")

    WebElement setupsubmitButton;    
    
    
    @FindBy(className="message_content")

    WebElement SucessStoreMessage;    
    
    
    @FindBy(id="countryDemographic")

    WebElement setupCountry;
    
    @FindBy(id="countryForSearch")

    WebElement setupCountrySearch;
    
    
    @FindBy(id="operation")

    WebElement setupOperation;   
    
    @FindBy(id="stateDemographic")

    WebElement setupState;    
    
    @FindBy(id="address1Demographic")

    WebElement setupAddress1;  
    
    @FindBy(id="cityDemographic")

    WebElement setupCity;  
    
    
    @FindBy(id="zipCodeDemographic")

    WebElement setupZipcode;  
    
    @FindBy(id="phoneNoDemographic")

    WebElement setupPhoneno;
    
    @FindBy(id="contactPersonDemographic")

    WebElement setupContactPerson;
    
    @FindBy(id="emailIdDemographic")

    WebElement setupEmailID;
    
    
    @FindBy(id="storeTypeDemographic")

    WebElement setupStoreType;
    
    @FindBy(id="lowerAmtLimit")

    WebElement setupLowerAmtLimit; 
    
    @FindBy(id="upperAmtLimit")

    WebElement setupUpperAmtLimit; 
    

    //Stores
    
    @FindBy(partialLinkText="FIND")

    WebElement setupFindStore; 
    
    
    @FindBy(id="storeId")

    WebElement setupFindStoreID;
    
    @FindBy(id="SubmitStoreSearch")

    WebElement setupSubmitSearch;
    
    
    @FindBy(xpath="//*[@title=\"Modify Store\"]")

    WebElement setupmodifyStoreID;

     @FindBy(partialLinkText="CREDIT IN")
     WebElement setupCreditInfo;
    
     @FindBy(partialLinkText="DCC IN")
     WebElement setupDCCInfo;
     
     
     
     
    
     
     @FindBy(id="ca_merchantProcessor")

     WebElement setupProcessorName;
     
     @FindBy(id="ar_merchantProcessor")

     WebElement setupSecondaryProcessorName;
     
     
     @FindBy(id="ca_mrcId")

     WebElement setupCardAcceptorID;
     
     @FindBy(id="ar_mrcId")

     WebElement setupSecondaryCardAcceptorID;
     
     
     @FindBy(id="ca_TERMINAL_LABEL_0")

     WebElement setupTerminalLabel;
     
     @FindBy(id="ca_TERMINAL_ID_0")

     WebElement setupTerminalID;
     
     @FindBy(id="Submit")

     WebElement setupCreditSubmit;
     
     @FindBy(xpath="//*[contains(text(),'DEBIT INFO')]")

     WebElement setupDebitinfo;
     
     @FindBy(xpath="//*[contains(text(),'PREPAID INFO')]")

     WebElement setupPrepaidinfo;
     
     @FindBy(xpath="//*[contains(text(),'EBT INFO')]")

     WebElement setupEBTinfo;
     
     @FindBy(xpath="//*[contains(text(),'GIFT INFO')]")

     WebElement setupGiftinfo;
     
     @FindBy(xpath="//*[contains(text(),'FLEET INFO')]")

     WebElement setupFleetinfo;
     
     @FindBy(xpath="//*[contains(text(),'FSA INFO')]")

     WebElement setupFSAinfo;
   

     
     @FindBy(id="ca_mrcCategoryCode")
     WebElement setupMerchantCode;
     
     @FindBy(id="ar_mrcCategoryCode")
     WebElement setupSecondaryMerchantCode;
     
     
     @FindBy(id="errorMsg")
     WebElement setupMerchantCodeError;
    
     @FindBy(xpath="//img[@src='/whizpay/images/btnok.gif']")

     WebElement ErrorMessageOk;    
     
     
     @FindBy(id="ar_tenderType")
     WebElement setupAddSecondaryProcessor;
     
     @FindBy(partialLinkText="HELPDESK MANAGEMENT")
     WebElement setupHelpDesk;
     
     @FindBy(partialLinkText="BULK STORE CREATION")
     WebElement setupBulkStore;
     
     @FindBy(xpath="//input[@id='uploadCSVFile']")
     WebElement setupFileUpload;
     
     @FindBy(id="uploadGoldTemplate")
     WebElement setupGoldTemplateUpload;
     
     @FindBy(id="nextid")
     WebElement setupUploadButton;
     
     @FindBy(id="startSchedular")
     WebElement setupShedular;
     
     @FindBy(id="ca_userName")
     WebElement setupUsername;
     
     @FindBy(id="ca_password")
     WebElement setupPassword;
     
     
     @FindBy(id="ca_dwrMrcId")
     WebElement setupRapidConnectMerchantId;
     
     @FindBy(id="ca_clientId")
     WebElement setupClientID; 
     
     
     @FindBy(id="ca_groupId")
     WebElement setupGroupId; 
     
     @FindBy(id="ca_connectivityType")
     WebElement setupConnectivityType; 
     
     
     @FindBy(id="ca_tppId")
     WebElement setupTPPId; 
     
     
     @FindBy(linkText="Template Management System")
     WebElement setupTemplateSystem;
     
     @FindBy(linkText="TEMPLATE MANAGEMENT")
     WebElement setupTemplateInfo;
    
     @FindBy(linkText="GOLD TEMPLATE")
     WebElement setupGoldTemplate; 
     
     @FindBy(id="terminalVal")	
     WebElement setupTerminalType; 
     
     @FindBy(id="baseApplication")
     WebElement setupBaseAppplicationdrop; 
     
     @FindBy(id="glTemplateName")
     WebElement setupGoldTemplateName; 
     
     @FindBy(id="glTemplateName1")
     WebElement setupGoldTemplateName1; 
     
     
     @FindBy(id="storeTypeVal")
     WebElement setupStoreTypeval; 
     
     @FindBy(id="departmentTypeVal")
     WebElement setupDepartmentTypeval; 
     

     @FindBy(name="Submit1")
     WebElement setupGoldSubmit; 
     
     @FindBy(id="EmailId")
     WebElement setupGoldAPProveEmail;
     
     @FindBy(xpath="//*[contains(text(),'MODIFY')]")

     WebElement setupGoldmodify;
     
     @FindBy(xpath="//a[@class='sidesublink'][contains(text(),'VIEW')]") 

     WebElement setupGoldView;
     
     
     @FindBy(id="softwareVersion")
     WebElement setupSelectViewBaseApplication; 
     
     @FindBy(id="goldTemplateName")
     WebElement setupSelectViewGoldTemplateName; 
     
     @FindBy(id="ca_tenderType")
     WebElement setupPrimarySetup; 
     
     @FindBy(id="ca_connectivityType")
     WebElement setupConnectivity; 
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     

    public HomePage(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }   

   
       
        
        
        public void clickSetupStore(){

        	setupStore.click();

    } 
        
        public void setCorpName(String strCorpName){

        	setupCorporateName.clear();
        	setupCorporateName.sendKeys(strCorpName);     
        }
        
        public void clickSubmitCorpSearch(){

        	submitcorpsearch.click();

    } 
        public void clickAddStore(){

        	AddStorelink.click();

    } 
        public void setStoreNameDemographic(String strStoreName){

        	setupstoreNameDemographic.sendKeys(strStoreName);     
        }
        public void setStoreIDDemographic(String strStoreID){

        	setupstoreIdDemographic.sendKeys(strStoreID);     
        }
        
        public void clickSubmitStore(){

        	setupsubmitButton.click();

    } 
        
        
        public WebElement SucessMessage()
        {

        return SucessStoreMessage;
        }
        
        
        public void clickContryDrop(){

        	setupCountry.click();
            Select drop = new Select(setupCountry);
            drop.selectByIndex(3);  
    } 
        public void clickContryDropSearch(){

        	setupCountrySearch.click();
            Select drop = new Select(setupCountrySearch);
            drop.selectByIndex(3);  
    }  
        public void clickTerminalTypeDropSearch(){

        	setupTerminalType.click();
            Select drop = new Select(setupTerminalType);
            drop.selectByIndex(1);  
    }  
        public void clickBaseapplicationDropSearch(){

        	setupBaseAppplicationdrop.click();
            Select drop = new Select(setupBaseAppplicationdrop);
            drop.selectByIndex(1);  
    }   
        
        public void clickStoreTypeVal(){

        	setupStoreTypeval.click();
            Select drop = new Select(setupStoreTypeval);
            drop.selectByIndex(3);  
    } 
        public void clickDepartmentTypeVal(){
        //	String period = configFileReader.getDepartmentType();
        	
        	// Reporter.log(period+"Validation Checked");
        	setupDepartmentTypeval.click();
            Select drop = new Select(setupDepartmentTypeval);
           drop.selectByIndex(0); 
          
            //drop.selectByVisibleText (period);
            
 
         
    }  
        
        public void clickStateDrop(){

        	setupState.click();
            Select drop = new Select(setupState);
            drop.selectByIndex(2);  
    } 
        
        public void clickOperation(){

        	setupOperation.click();
            Select drop = new Select(setupOperation);
            drop.selectByIndex(1);  
    }  
        
        public void setAddress1(String strAddress1){

        	setupAddress1.sendKeys(strAddress1);     
        }
      
        
        public void setCity1(String strCity1){

        	setupCity.sendKeys(strCity1);     
        }
        
        public void setZip1(String strZip1){

        	setupZipcode.sendKeys(strZip1);     
        }
        
        public void setPhone1(String strPhone1){

        	setupPhoneno.sendKeys(strPhone1);     
        }
        
        public void setContactPerson1(String strContactPerson1){

        	setupContactPerson.sendKeys(strContactPerson1);     
        }
        
        public void setEmailID1(String strEmailId1){

        	setupEmailID.sendKeys(strEmailId1);     
        }
        
        public void clickStoreTypeDrop(){

        	setupStoreType.click();
            Select drop = new Select(setupStoreType);
            drop.selectByIndex(2);  
    } 
        public void setLowerAmount1(String strLowerAmount){

        	setupLowerAmtLimit.sendKeys(strLowerAmount);     
        }
        
        public void setUpperAmount1(String strUpperAmount){

        	setupUpperAmtLimit.sendKeys(strUpperAmount);     
        }
        
        
        public void clickFindStore(){

        	setupFindStore.click();

    } 
        
        
        public void setStoreByID(String strStoreid){

        	setupFindStoreID.sendKeys(strStoreid);     
        }
        
        
        public void clickModifyFindStore(){

        	setupmodifyStoreID.click();

    } 
        
        public void clickSubmitFindStore(){

        	setupSubmitSearch.click();

    }   
        
        public void clickCreditInfo(){

        	setupCreditInfo.click();

    }  
        
        public void clickDCCInfo(){

        	setupDCCInfo.click();

    } 
         
        public void clickCreditProcessorNameDrop(){

        
        	setupProcessorName.click();
        	
            Select drop = new Select(setupProcessorName);
            drop.selectByVisibleText("Amex Processor"); 
    }  
        
        
        public void setCardAcceptorID(String strCardAcceptorid){

        	setupCardAcceptorID.clear();
        	setupCardAcceptorID.sendKeys(strCardAcceptorid);     
        } 
        
        public void setTerminal(String strTerminalId){

        	setupTerminalLabel.clear();
        	setupTerminalLabel.sendKeys(strTerminalId);     
        } 
        
        public void setTerminalID(String strTerminalId1){

        	setupTerminalID.clear();
        	setupTerminalID.sendKeys(strTerminalId1);     
        } 
        
        public void clickCreditSubmitInfo(){

        	setupCreditSubmit.click();

    }     
        
        
        public void clickDebitInfo(){

        	setupDebitinfo.click();

    }      
        
        public void clickDebitProcessorNameDrop(){

        	setupProcessorName.click();
            Select drop = new Select(setupProcessorName);
            drop.selectByVisibleText("Comercia Processor"); 
    }   
        
        
        public void setDebitTerminal(String strTerminalId){
        	setupTerminalLabel.clear();
        	setupTerminalLabel.sendKeys(strTerminalId);     
        } 
        
        public void setDebitTerminalID(String strTerminalId1){
        	setupTerminalID.clear();
        	setupTerminalID.sendKeys(strTerminalId1);     
        } 
        
        public void clickDebitSubmitInfo(){

        	setupCreditSubmit.click();

    }     
        
        public void setDebitCardAcceptorID(String strCardAcceptorid){

        	setupCardAcceptorID.clear();
        	setupCardAcceptorID.sendKeys(strCardAcceptorid);     
        } 
        
        public void clickPrepaidInfo(){

        	setupPrepaidinfo.click();

    }    
        public void clickEBTInfo(){

        	setupEBTinfo.click();

    }    
        public void clickFleetInfo(){

        	setupFleetinfo.click();

    }    
        public void clickFSAInfo(){

        	setupFSAinfo.click();

    }   
        
        public void clickGiftInfo(){

        	setupGiftinfo.click();

    }    
        
        
        public void clickPrepaidProcessorNameDrop(){

        	setupProcessorName.click();
            Select drop = new Select(setupProcessorName);
            drop.selectByVisibleText("Blackhawk Processor"); 
    }  
        
        public void clickGiftProcessorNameDrop(){

        	setupProcessorName.click();
            Select drop = new Select(setupProcessorName);
            drop.selectByVisibleText("Blackhawk Processor"); 
    }  
        
        public void clickEBTProcessorNameDrop(){

        	setupProcessorName.click();
            Select drop = new Select(setupProcessorName);
            drop.selectByVisibleText("Paymenttech"); 
    }
        public void clickFleetProcessorNameDrop(){

        	setupProcessorName.click();
            Select drop = new Select(setupProcessorName);
            drop.selectByVisibleText("FD Rapid Connect Processor"); 
    }
        public void clickFSAProcessorNameDrop(){

        	setupProcessorName.click();
            Select drop = new Select(setupProcessorName);
            drop.selectByVisibleText("FD Rapid Connect Processor"); 
    }
        
        
        public void clickDCCProcessorNameDrop(){

        	setupProcessorName.click();
            Select drop = new Select(setupProcessorName);
            drop.selectByVisibleText("Forum Pay Processor"); 
    }
        
        public void clickSecondaryPrepaidProcessorNameDrop(){

        	setupSecondaryProcessorName.click();
            Select drop = new Select(setupSecondaryProcessorName);
            drop.selectByVisibleText("Blackhawk Processor"); 
    }  
        public void clickSecondaryGiftProcessorNameDrop(){

        	setupSecondaryProcessorName.click();
            Select drop = new Select(setupSecondaryProcessorName);
            drop.selectByVisibleText("Blackhawk Processor"); 
    }  
        
        
        public void setPrepaidMerchantCode(String strmerchantCode){

        	setupMerchantCode.clear();
        	setupMerchantCode.sendKeys(strmerchantCode);     
        } 
        
        public void setSecondaryPrepaidMerchantCode(String strmerchantCode){

        	setupSecondaryMerchantCode.clear();
        	setupSecondaryMerchantCode.sendKeys(strmerchantCode);     
        } 
        
        
        public void setPrepaidMerchantID(String strMerchantid){
        	setupCardAcceptorID.clear();
        	setupCardAcceptorID.sendKeys(strMerchantid);     
        } 
        
        public void setFSAMerchantID(String strMerchantid){
        	setupCardAcceptorID.clear();
        	setupCardAcceptorID.sendKeys(strMerchantid);     
        } 
        public void setSecondaryPrepaidMerchantID(String strMerchantid){
        	setupSecondaryCardAcceptorID.clear();
        	setupSecondaryCardAcceptorID.sendKeys(strMerchantid);     
        } 
        
        
        
        public void clickPrepaidSubmitInfo(){

        	setupCreditSubmit.click();

    }    
        public void clickEBTSubmitInfo(){

        	setupCreditSubmit.click();

    }    
        public void clickFleetSubmitInfo(){

        	setupCreditSubmit.click();

    }    
        public void clickFSASubmitInfo(){

        	setupCreditSubmit.click();

    }    
        public void clickDCCSubmitInfo(){

        	setupCreditSubmit.click();

    }    
        
        public void clickPrepaidsetupMerchantCodeError(){

        	setupMerchantCodeError.click();
        	ErrorMessageOk.click();

    }    
        
        
        
        public void clickAddAnotherProcessor(){
        	if(setupAddSecondaryProcessor.isSelected())
        	{
        	setupAddSecondaryProcessor.click();
        	}

    } 
        
        public void clickHelpDesk(){

        	setupHelpDesk.click();

    } 
        public void clickBulkStore(){

        	setupBulkStore.click();

    }    
        
        public void clickTemplateInfo(){

        	setupTemplateInfo.click();

    }    
        
        public void clickTemplateSystem(){

        	setupTemplateSystem.click();

    }    
        
        public void clickGoldTemplateInfo(){

        	setupGoldTemplate.click();

    }    
        
        
        
        public void clickSetupFileupload(){
        	
        	
        	setupFileUpload.sendKeys(onboardingFilePath);
        	//setupFileUpload.click();

    }    
        
  public void clickSetupGoldFileupload(){
        	
        	
	  setupGoldTemplateUpload.sendKeys(goldFilePath);
        	//setupFileUpload.click();

    }       
        
        
        
        public void clickUploadButton(){

        	setupUploadButton.click();

    }    
        
        public void clickShedularButton(){

        	setupShedular.click();

    }     
        
        
        public void setUsername(String strUsername){

        	setupUsername.clear();
        	setupUsername.sendKeys(strUsername);     
        } 
        
        public void setPassword(String strPassword){

        	setupPassword.clear();
        	setupPassword.sendKeys(strPassword);     
        } 
        
        public void setRapidConnectMerchantId(String strRapidMerchantId){

        	setupRapidConnectMerchantId.clear();
        	setupRapidConnectMerchantId.sendKeys(strRapidMerchantId);     
        } 
        
        public void setClientId(String strClientId){

        	setupClientID.clear();
        	setupClientID.sendKeys(strClientId);     
        } 
        
        public void clickGroupID(){

        	setupGroupId.click();
            Select drop = new Select(setupGroupId);
            drop.selectByVisibleText("10001(Nashville)"); 
    }  
        public void clickConnectivityType(){

        	setupConnectivityType.click();
            Select drop = new Select(setupConnectivityType);
            drop.selectByVisibleText("VPN (Persistent)"); 
    }  
        
        
        public void clickTPPID(){

        	setupTPPId.click();
            Select drop = new Select(setupTPPId);
            drop.selectByVisibleText("RAU002"); 
    }   
        
        
        
        public void setGoldName(String strgold){

        	setupGoldTemplateName.clear();
        	setupGoldTemplateName.sendKeys(strgold);     
        } 
        
        public void setGoldName1(String strgold){

        	setupGoldTemplateName1.clear();
        	setupGoldTemplateName1.sendKeys(strgold);     
        } 
        
        
        
        
        
        public void clickSubmitGoldTemplate(){

        	setupGoldSubmit.click();

    }   
        
        public void setGoldEmailApproval(String strgoldemail){

        	setupGoldAPProveEmail.clear();
        	setupGoldAPProveEmail.sendKeys(strgoldemail);     
        } 
        
        public void clickModifyGoldTemplate(){

        	setupGoldmodify.click();

    }   
        
        public void clickViewGoldTemplate(){

        	setupGoldView.click();

    }   
        
        public void clickDropBaseApplication(){

        	setupSelectViewBaseApplication.click();
            Select drop = new Select(setupSelectViewBaseApplication);
            drop.selectByVisibleText("Vikram_v30.7"); 
    }  
        
        public void clickDropGoldTemplateName(){

        	setupSelectViewGoldTemplateName.click();
            Select drop = new Select(setupSelectViewGoldTemplateName);
            drop.selectByValue("43645");//("Vikram_v30.7_MX915_272"); 
    }    
          
        
        
        
        public void clickPrimarySetup(){

        	setupPrimarySetup.click();

    }   
        
        
        
       /* public void clickContryDropSearch(){

        	setupCountrySearch.click();
            Select drop = new Select(setupCountrySearch);
            drop.selectByIndex(3);  
    }  
        */
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        public void SetupStore(){

        	this.clickSetupStore();
   
            }
        
        public void setCorporate(String strCorporate){

        	
        	this.setCorpName(strCorporate);
        	

            }
        
        
        public void SetSubmitCorpSearch(){

        	this.clickSubmitCorpSearch();
   
            }
        public void AddStoreLink(){

        	this.clickAddStore();
   
            }
        
        public void setStoreName(String strStoreName){

        	
        	this.setStoreNameDemographic(strStoreName);
        	

            }
 
        public void setStoreID(String strStoreID){

 	
        	this.setStoreIDDemographic(strStoreID);
 	

        	}
        public void SubmitStorePage(){

        	this.clickSubmitStore();
   
            }
        
        
        public WebElement explicitWait() {
            WebDriverWait w=new WebDriverWait(driver, 5, 200);
            return w.until(ExpectedConditions.visibilityOf(SucessStoreMessage)); 


        }
        
        public void SetupContrydrop(){

        	this.clickContryDrop();
   
            }
        public void SetupContrydropSearch(){

        	this.clickContryDropSearch();
   
            }
        public void SetupTerminalTYpedropSearch(){

        	this.clickTerminalTypeDropSearch();
   
            }
        public void SetupBaseApplicationpedropSearch(){

        	this.clickBaseapplicationDropSearch();
   
            }
        
        
        public void SetupStatedrop(){

        	this.clickStateDrop();
   
            }
        public void SetupStorTypeVal(){

        	this.clickStoreTypeVal();
   
            }
        
        public void SetupDepartmentTypeVal(){

        	this.clickDepartmentTypeVal();
   
            }
        public void SetupOperation(){

        	this.clickOperation();
   
            }
        
        
        public void setupAddress1(String strAddr1){

        	
        	this.setAddress1(strAddr1);
        	

            }
        public void setupCity(String strCity1){

        	
        	this.setCity1(strCity1);
        	

            }
        public void setupZip(String strZip1){

        	
        	this.setZip1(strZip1);
        	

            }
        public void setupPhone(String strPhone1){

        	
        	this.setPhone1(strPhone1);
        	

            }
        public void setupContactPerson(String strContactPerson1){

        	
        	this.setContactPerson1(strContactPerson1);
        	

            }
        public void setupEmailID(String strEmailId1){

        	
        	this.setEmailID1(strEmailId1);
        	

            }
        
        
        public void SetupCreditProcessorname(){

        	this.clickCreditProcessorNameDrop();
   
            }
        
       
        
        public void SetupStoreTypedrop(){

        	this.clickStoreTypeDrop();
   
            }
        
        public void SetupLowerAmount(String strlamount1){

        	this.setLowerAmount1(strlamount1);
   
            }
        
        public void SetupUpperAmount(String strUpperAmount1){

        	this.setUpperAmount1(strUpperAmount1);
   
            }
        
        public void SetupFindStore(){

        	this.clickFindStore();
   
            }
        public void SetupFindStoreBYID(String strStoreById){

        	this.setStoreByID(strStoreById);
   
            }
        
        public void SetupViewModifyFindStore(){

        	this.clickModifyFindStore();
   
            }
        public void SetupSubmitFindStore(){

        	this.clickSubmitFindStore();
   
            }
        public void SetupCreditInfoLink(){

        	this.clickCreditInfo();
   
            }
        public void SetupDCCInfoLink(){

        	this.clickDCCInfo();
   
            }
        
        
        public void SetupCardAcceptorIDMain(String strCardId){

        	this.setCardAcceptorID(strCardId);
   
            }
        
        public void SetupTerminalLabelmain(String strTerminalLabel){

        	this.setTerminal(strTerminalLabel);
   
            }
        
        public void SetupTerminalIDmain(String strTerminalID){

        	this.setTerminalID(strTerminalID);
   
            }
        
        public void SetupCreditSubmit(){

        	this.clickCreditSubmitInfo();
   
            }
        
        public void SetupDebitInfoLink(){

        	this.clickDebitInfo();
   
            }
        
        public void SetupEBTSubmit(){

        	this.clickEBTSubmitInfo();
   
            }
        public void SetupFleetSubmit(){

        	this.clickFleetSubmitInfo();
   
            }
        
        public void SetupFSASubmit(){

        	this.clickFSASubmitInfo();
   
            }
        
        
        public void SetupDebitProcessorname(){

        	this.clickDebitProcessorNameDrop();
   
            }
        
        public void SetupDebitTerminalLabel(String strTerminalLabel){

        	this.setDebitTerminal(strTerminalLabel);
   
            }
        
        public void SetupDebitTerminalID(String strTerminalID){

        	this.setDebitTerminalID(strTerminalID);
   
            }
        
        public void SetupDebitSubmit(){

        	this.clickDebitSubmitInfo();
   
            }
        
        public void SetupDebitCardAcceptorID(String strCardId){

        	this.setDebitCardAcceptorID(strCardId);
   
            }
        
        public void SetupPrepaidInfoLink(){

        	this.clickPrepaidInfo();
   
            }
        
        public void SetupGiftInfoLink(){

        	this.clickGiftInfo();
   
            }
        
        public void SetupEBTInfoLink(){

        	this.clickEBTInfo();
   
            }
        
        public void SetupFleetInfoLink(){

        	this.clickFleetInfo();
   
            }
        
        public void SetupFSAInfoLink(){

        	this.clickFSAInfo();
   
            }
        
        public void SetupPrepaidProcessorname(){

        	this.clickPrepaidProcessorNameDrop();
   
            }
        
        public void SetupGiftProcessorname(){

        	this.clickGiftProcessorNameDrop();
   
            }
        
        public void SetupEBTProcessorname(){

        	this.clickEBTProcessorNameDrop();
   
            }
        public void SetupFleetProcessorname(){

        	this.clickFleetProcessorNameDrop();
   
            }
        public void SetupFSAProcessorname(){

        	this.clickFSAProcessorNameDrop();
   
            }
        public void SetupDCCProcessorname(){

        	this.clickDCCProcessorNameDrop();
   
            }
        
        
        
        public void SetupSecondaryPrepaidProcessorname(){

        	this.clickSecondaryPrepaidProcessorNameDrop();
   
            }
        
        public void SetupSecondaryGiftProcessorname(){

        	this.clickSecondaryGiftProcessorNameDrop();
   
            }
        
        public void SetupPrepaidMerchantCode(String strMerchantcode){

        	this.setPrepaidMerchantCode(strMerchantcode);
   
            }
        public void SetupSecondaryPrepaidMerchantCode(String strMerchantcode){

        	this.setSecondaryPrepaidMerchantCode(strMerchantcode);
   
            }
        public void SetupPrepaidMerchantID(String strMerchantId){

        	this.setPrepaidMerchantID(strMerchantId);
   
            }
        
        public void SetupFSAMerchantID(String strMerchantId){

        	this.setFSAMerchantID(strMerchantId);
   
            }
        
        public void SetupSecondaryPrepaidMerchantID(String strMerchantId){

        	this.setSecondaryPrepaidMerchantID(strMerchantId);
   
            }
        
        public void SetupPrepaidSubmit(){

        	this.clickPrepaidSubmitInfo();
   
            }
        
        public void SetupErrorOk(){

        	this.clickPrepaidsetupMerchantCodeError();
   
            }
        public void SetupAddAnotherProcessor(){

        	this.clickAddAnotherProcessor();
   
            }
        public void SetupHelpDeskMangement(){

        	this.clickHelpDesk();
   
            }
        public void SetupBulkStore(){

        	this.clickBulkStore();
   
            }
        public void SetupTemplate(){

        	this.clickTemplateInfo();
   
            }
        public void SetupTemplateSystem(){

        	this.clickTemplateSystem();
   
            }
        
        public void SetupGoldTemplate(){

        	this.clickGoldTemplateInfo();
   
            }
        
        public void SetupFileUpload(){

        	this.clickSetupFileupload();
   
            }
        
        public void SetupGoldFileUpload(){

        	this.clickSetupGoldFileupload();
   
            }
        
        
        public void SetupUploadButtonFile(){

        	this.clickUploadButton();
   
            }
        public void SetupShedularButton(){

        	this.clickShedularButton();
   
            }
        public void SetupUserName(String strUname){

        	this.setUsername(strUname);
   
            }
        public void SetupPassword(String strPWD){

        	this.setPassword(strPWD);
   
            }
        public void SetupRapidConnectMerchantId(String strRapidMerchantId){

        	this.setRapidConnectMerchantId(strRapidMerchantId);
   
            }
        
        public void SetupClientId(String strClientId){

        	this.setClientId(strClientId);
   
            }
        public void SetupGroupID(){

        	this.clickGroupID();
   
            }
        public void SetupConnectivityType(){

        	this.clickConnectivityType();
   
            }
        
        public void SetupTPPID(){

        	this.clickTPPID();
   
            }
        
        public void SetupGoldTemplateName(String strGold){

        	this.setGoldName(strGold);
   
            }
        
        public void SetupGoldTemplateName1(String strGold){

        	this.setGoldName1(strGold);
   
            }
        
        public void SetupGoldTemplateSubmit(){

        	this.clickSubmitGoldTemplate();
   
            } 
        
        public void SetupGoldTemplateEmailApproval(String strGoldemailname){

        	this.setGoldEmailApproval(strGoldemailname);
   
            }
        public void SetupModifyGoldTemplate(){

        	this.clickModifyGoldTemplate();
   
            } 
        public void SetupViewGoldTemplate(){

        	this.clickViewGoldTemplate();
   
            } 
        public void SetupSelectBaseApplication(){

        	this.clickDropBaseApplication();
   
            } 
        
        public void SetupSelectGoldTemplateName(){

        	this.clickDropGoldTemplateName();
   
            } 
        
        public void SetupPrimarySetup(){

        	this.clickPrimarySetup();
   
            } 
        
        
        
        
        
}
