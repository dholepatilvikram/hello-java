package com.backoffice.PageFactory;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.PageFactory;


public class LoginPage {
	/**

     * All WebElements are identified by @FindBy annotation

     */

    WebDriver driver;

    @FindBy(name="userName")

    WebElement user99GuruName;

    @FindBy(id="userEnteredPassword") //for UAT
    
    //@FindBy(id="password")// for prod

    WebElement password99Guru;    

   // @FindBy(className="barone")

   // WebElement titleText;

    @FindBy(xpath="/html[1]/body[1]/div[1]/form[1]/div[2]/div[3]/button[1]")
   
    WebElement login;
    
    @FindBy(id="securityAnswerInput")

    WebElement securityAnswer;
    
    @FindBy(xpath="/html[1]/body[1]/div[1]/form[1]/div[2]/button[1]")
    

    WebElement SecurityPageSubmit;
    
    @FindBy(id="odtpassword")

    WebElement odtpassword;
    
    @FindBy(xpath="/html[1]/body[1]/div[1]/form[1]/div[2]/div[5]/button[1]")

    WebElement ODTPageSubmit;
    
    

    public LoginPage(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }

    //Set user name in textbox

    public void setUserName(String strUserName){

        user99GuruName.sendKeys(strUserName);     
    }

    //Set password in password textbox

    public void setPassword(String strPassword){

    password99Guru.sendKeys(strPassword);

    }

    //Click on login button

    public void clickLogin(){

            login.click();

    }  
    
    public void setSecurityAnswer(String strSecurityAnswer){

    	securityAnswer.sendKeys(strSecurityAnswer);

        }
    
    public void clickSecurityPageSubmit(){

    	SecurityPageSubmit.click();

}  
    
    public void setODT(String strODT){

    	odtpassword.sendKeys(strODT);

        }
   
    public void clickODTPageSubmit(){

    	ODTPageSubmit.click();

}  
    
    
    
    
    
   
    
    
 
    public void loginToGuru99(String strUserName,String strPasword){

        //Fill user name

        this.setUserName(strUserName);

        //Fill password

        this.setPassword(strPasword);

        //Click Login button

        this.clickLogin();       
        
          

    }
    
  
   /*UAT*/
    public void SetSecurityAnswer(String strSecurityAnswer){

        //Fill user name

        this.setSecurityAnswer(strSecurityAnswer);

        
          this.clickSecurityPageSubmit();

    }
    
    
    public void SetODT(String strODT){

    	this.setODT(strODT);
    	
    	this.clickODTPageSubmit();

        }

   
}
