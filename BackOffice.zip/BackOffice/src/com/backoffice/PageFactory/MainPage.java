package com.backoffice.PageFactory;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.PageFactory;


public class MainPage {
	


    WebDriver driver;


    @FindBy(xpath="//a[contains(text(),'Setup Terminal')]")

    WebElement setupStore;    
    

    public MainPage(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }

    public void clickSetupStore(){

    	setupStore.click();

} 

    
    
    
   
    
    public void SetupStore(){

    	this.clickSetupStore();

        }

   
}
